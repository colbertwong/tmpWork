package test.stub.webcasapi.v1;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;

@RestController
@RequestMapping(value = "/rtm/v1", method = RequestMethod.POST)
public class Api {
    @PostMapping("/delivery_log_list")
    public ResponseEntity<String> deliveryLogList() throws IOException, URISyntaxException {

        String jsonString = readJsonFile("delivery_log_list.json");
        System.out.println(jsonString);
        JSONObject json = new JSONObject(new JSONTokener(jsonString));
        int code = json.getInt("code");
        JSONObject body = json.getJSONObject("body");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new ResponseEntity<>(body.toString(), headers, code);
    }

    public String readJsonFile(String fileName) throws IOException, URISyntaxException {
        String path = System.getProperty("user.dir");
        File jsonFile = new File(path + "/" + fileName);
        BufferedReader reader = new BufferedReader(new FileReader(jsonFile));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line).append("\n");
        }
        reader.close();
        return stringBuilder.toString();
    }
}
