package test.stub.webcasapi;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResponseEntity<String> handleAllExceptions(Exception ex) {
        // 处理异常，返回自定义的响应
        return new ResponseEntity<>("Custom error message: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}